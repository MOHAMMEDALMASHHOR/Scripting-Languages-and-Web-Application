<?php
require_once 'Node.php';

class Layer {
    private $nodes = [];

    public function __construct($num_nodes, $num_inputs_per_node) {
        for ($i = 0; $i < $num_nodes; $i++) {
            $this->nodes[] = new Node($num_inputs_per_node);
        }
    }

    public function forward($inputs) {
        $outputs = [];
        foreach ($this->nodes as $node) {
            $outputs[] = $node->activate($inputs);
        }
        return $outputs;
    }
}
?>