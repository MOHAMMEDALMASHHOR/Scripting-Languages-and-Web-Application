<?php
class Node {
    private $weights = [];
    private $bias;

    public function __construct($num_inputs) {
        for ($i = 0; $i < $num_inputs; $i++) {
            $this->weights[] = rand() / getrandmax();
        }
        $this->bias = rand() / getrandmax();
    }

    private function sigmoid($x) {
        return 1 / (1 + exp(-$x));
    }

    public function activate($inputs) {
        $sum = 0;
        for ($i = 0; $i < count($inputs); $i++) {
            $sum += $inputs[$i] * $this->weights[$i];
        }
        $sum += $this->bias;
        return $this->sigmoid($sum);
    }
}
?>