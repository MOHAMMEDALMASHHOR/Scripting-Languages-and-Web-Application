<?php
require_once 'Ann.php';

$ann = new Ann();
$input = [1.0, 0.5];
$output = $ann->forward($input);
echo "ANN Output: " . $output . "\n";
?>