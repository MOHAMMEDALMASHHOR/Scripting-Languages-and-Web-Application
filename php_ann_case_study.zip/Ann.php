<?php
require_once 'Layer.php';

class Ann {
    private $layers = [];

    public function __construct() {
        $this->layers[] = new Layer(2, 2); // 2 input to 2 hidden
        $this->layers[] = new Layer(1, 2); // 2 hidden to 1 output
    }

    public function forward($inputs) {
        $outputs = $inputs;
        foreach ($this->layers as $layer) {
            $outputs = $layer->forward($outputs);
        }
        return $outputs[0]; // Single output
    }
}
?>